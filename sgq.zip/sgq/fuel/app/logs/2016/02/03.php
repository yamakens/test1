<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-02-03 16:00:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 16:45:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 16:53:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 16:53:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 16:53:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 17:03:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 17:30:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 17:31:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 18:04:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-02-03 18:04:32 --> Notice - Undefined variable: pagination in C:\Apache2\htdocs\sgq\fuel\app\views\item\list.php on line 13
WARNING - 2016-02-03 18:05:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 18:07:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-02-03 18:08:43 --> Fatal Error - Undefined class constant 'forge' in C:\Apache2\htdocs\sgq\fuel\packages\oil\classes\console.php(116) : eval()'d code on line 1
WARNING - 2016-02-03 18:09:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-03 18:33:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-02-03 18:40:49 --> Parsing Error - syntax error, unexpected ';' in C:\Apache2\htdocs\sgq\fuel\packages\oil\classes\console.php(116) : eval()'d code on line 1
