<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-02-04 14:44:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-04 18:16:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-04 18:17:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-02-04 18:38:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-02-04 18:38:55 --> Error - The requested view could not be found: item/view.php in C:\Apache2\htdocs\sgq\fuel\core\classes\view.php on line 398
