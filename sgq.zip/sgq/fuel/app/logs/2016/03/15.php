<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-03-15 10:52:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 10:52:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 11:02:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 11:03:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 11:07:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 11:10:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 11:24:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:16:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:16:13 --> Notice - Undefined variable: data in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 435
WARNING - 2016-03-15 17:17:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:17:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:17:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:19:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:19:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:19:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:31:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:31:05 --> Fatal Error - Call to a member function field() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:31:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:31:47 --> Fatal Error - Call to a member function field() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:32:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:32:45 --> Fatal Error - Call to a member function field() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:33:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:33:00 --> Fatal Error - Call to a member function field() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:33:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:33:43 --> Fatal Error - Call to a member function field() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:35:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:35:34 --> Fatal Error - Call to a member function field() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:35:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:38:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:38:11 --> Error - View variable is not set: content in C:\Apache2\htdocs\sgq\fuel\core\classes\view.php on line 450
WARNING - 2016-03-15 17:40:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:40:57 --> Fatal Error - Call to a member function field() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:41:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-15 17:41:33 --> Parsing Error - syntax error, unexpected '$fieldset' (T_VARIABLE) in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 7
WARNING - 2016-03-15 17:41:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:48:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-15 17:48:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
