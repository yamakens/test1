<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-03-11 12:11:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 12:11:30 --> Fatal Error - Call to undefined method Fuel\Core\Fieldset::fields() in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 440
WARNING - 2016-03-11 12:11:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 12:11:48 --> Fatal Error - Call to undefined method Fuel\Core\Fieldset::fields() in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 440
WARNING - 2016-03-11 12:12:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:12:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:14:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 12:14:14 --> Fatal Error - Cannot access protected property Fuel\Core\Fieldset::$fields in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 439
WARNING - 2016-03-11 12:19:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 12:19:05 --> Fatal Error - Call to a member function build() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\form.php on line 4
WARNING - 2016-03-11 12:19:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 12:19:09 --> Fatal Error - Call to a member function build() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\form.php on line 4
WARNING - 2016-03-11 12:19:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:21:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:23:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:24:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:24:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:27:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:27:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:36:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:37:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:38:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:49:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:52:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 12:52:05 --> Warning - Illegal offset type in C:\Apache2\htdocs\sgq\fuel\core\classes\response.php on line 309
WARNING - 2016-03-11 12:54:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 12:54:27 --> Warning - Illegal offset type in C:\Apache2\htdocs\sgq\fuel\core\classes\response.php on line 309
WARNING - 2016-03-11 12:56:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:56:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 12:57:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 13:03:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 13:03:16 --> Notice - Undefined variable: title in C:\Apache2\htdocs\sgq\fuel\app\views\test\index.php on line 5
WARNING - 2016-03-11 13:03:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 13:05:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 13:06:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 13:06:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 13:06:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 13:06:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 13:08:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:05:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:06:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 15:06:01 --> Fatal Error - Call to a member function build() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 442
WARNING - 2016-03-11 15:06:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 15:06:37 --> Fatal Error - Call to undefined function var_char() in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 441
WARNING - 2016-03-11 15:07:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:07:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:12:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 15:12:19 --> Notice - Undefined index: label in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 441
WARNING - 2016-03-11 15:14:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:14:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:16:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 15:16:08 --> Fatal Error - Cannot access protected property Fuel\Core\Fieldset::$form in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 446
WARNING - 2016-03-11 15:17:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:19:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:29:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:29:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:30:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:30:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 15:30:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 16:51:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 16:51:26 --> Notice - Undefined offset: 1 in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 443
WARNING - 2016-03-11 16:52:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 16:52:44 --> Notice - Undefined index: validation in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 442
WARNING - 2016-03-11 16:53:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 16:54:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 16:54:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 16:54:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:45:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 18:45:38 --> Fatal Error - Call to a member function add_rule() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\classes\myutil.php on line 9
WARNING - 2016-03-11 18:46:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:53:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:53:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:53:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:53:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:53:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:53:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:54:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:54:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 18:54:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 19:01:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 19:02:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 19:04:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-11 19:07:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-11 19:07:09 --> Runtime Recoverable error - Argument 3 passed to Fuel\Core\Fieldset::add() must be of the type array, boolean given, called in C:\Apache2\htdocs\sgq\fuel\app\classes\myutil.php on line 6 and defined in C:\Apache2\htdocs\sgq\fuel\core\classes\fieldset.php on line 284
WARNING - 2016-03-11 19:12:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
