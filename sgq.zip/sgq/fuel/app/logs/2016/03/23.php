<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-03-23 14:10:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:10:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-23 14:10:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:10:44 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-23 14:11:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:11:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-23 14:11:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:11:30 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-23 14:11:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-23 14:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:11:36 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-23 14:13:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:13:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-23 14:13:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:13:03 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-23 14:13:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:13:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item"
INFO - 2016-03-23 14:13:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:13:12 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-23 14:13:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:13:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2/44"
INFO - 2016-03-23 14:13:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:13:24 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-23 14:13:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:13:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2/44"
INFO - 2016-03-23 14:13:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:13:27 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-23 14:41:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:41:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2/44"
INFO - 2016-03-23 14:41:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:41:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-23 14:41:12 --> Error - Call to undefined method Model_Item::chk_prop() in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 1074
WARNING - 2016-03-23 14:46:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-23 14:46:28 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2/44"
INFO - 2016-03-23 14:46:28 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-23 14:46:28 --> Fuel\Core\Request::execute - Setting main Request
