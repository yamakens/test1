<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-03-18 18:37:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-18 18:37:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-18 18:37:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-18 18:37:34 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-18 18:37:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-18 18:37:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-18 18:37:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-18 18:37:44 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2016-03-18 18:37:44 --> <input type="text" id="form_item_id_1" name="item_id_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" id="form_mall_id_1" name="mall_id_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" size="50" value="2" id="form_mall_item_name_1" name="mall_item_name_1" />

DEBUG - 2016-03-18 18:37:44 --> <input type="checkbox" checked="checked" id="form_is_output_1" name="is_output_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="checkbox" checked="checked" id="form_is_output_category1_1" name="is_output_category1_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="checkbox" id="form_is_output_category2_1" name="is_output_category2_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="checkbox" checked="checked" id="form_is_output_category3_1" name="is_output_category3_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="checkbox" id="form_is_output_category4_1" name="is_output_category4_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="checkbox" checked="checked" id="form_is_output_category5_1" name="is_output_category5_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" value="" id="form_sale_price_1" name="sale_price_1" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" value="" id="form_sale_price_rate_1" name="sale_price_rate_1" />

DEBUG - 2016-03-18 18:37:44 --> <input type="radio" id="form_tax_kbn_1_0" name="tax_kbn_1" value="1" /> <label for="form_tax_kbn_1_0">税込</label>
<input type="radio" id="form_tax_kbn_1_1" name="tax_kbn_1" value="2" /> <label for="form_tax_kbn_1_1">税別</label>


DEBUG - 2016-03-18 18:37:44 --> <input type="radio" id="form_postage_kbn_1_0" name="postage_kbn_1" value="1" /> <label for="form_postage_kbn_1_0">別</label>
<input type="radio" id="form_postage_kbn_1_1" name="postage_kbn_1" value="2" /> <label for="form_postage_kbn_1_1">込</label>


DEBUG - 2016-03-18 18:37:44 --> <input type="text" value="" id="form_sales_period_date_from_1" name="sales_period_date_from_1" />

DEBUG - 2016-03-18 18:37:44 --> <select id="form_sales_period_time_from_1" name="sales_period_time_from_1">
	<option value="0" selected="selected">00</option>
	<option value="1">01</option>
	<option value="2">02</option>
	<option value="3">03</option>
	<option value="4">04</option>
	<option value="5">05</option>
	<option value="6">06</option>
	<option value="7">07</option>
	<option value="8">08</option>
	<option value="9">09</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
</select>

DEBUG - 2016-03-18 18:37:44 --> <input type="text" value="" id="form_sales_period_date_to_1" name="sales_period_date_to_1" />

DEBUG - 2016-03-18 18:37:44 --> <select id="form_sales_period_time_to_1" name="sales_period_time_to_1">
	<option value="0" selected="selected">00</option>
	<option value="1">01</option>
	<option value="2">02</option>
	<option value="3">03</option>
	<option value="4">04</option>
	<option value="5">05</option>
	<option value="6">06</option>
	<option value="7">07</option>
	<option value="8">08</option>
	<option value="9">09</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
</select>

DEBUG - 2016-03-18 18:37:44 --> <input type="radio" id="form_is_order_limit_1_0" name="is_order_limit_1" value="1" /> <label for="form_is_order_limit_1_0">制限無し(自由入力)</label>
<input type="radio" id="form_is_order_limit_1_1" name="is_order_limit_1" value="2" /> <label for="form_is_order_limit_1_1">制限あり</label>


DEBUG - 2016-03-18 18:37:44 --> <input type="text" value="" id="form_is_order_limit_qty_1" name="is_order_limit_qty_1" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" id="form_stock_qty_1" name="stock_qty_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" id="form_reserve_qty_1" name="reserve_qty_1" value="" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" value="" id="form_category_1" name="category_1" />

DEBUG - 2016-03-18 18:37:44 --> <input type="text" value="" id="form_category_id_1" name="category_id_1" />

DEBUG - 2016-03-18 18:37:44 --> <input type="radio" id="form_storehouse_kbn_1_0" name="storehouse_kbn_1" value="1" /> <label for="form_storehouse_kbn_1_0">販売中</label>
<input type="radio" id="form_storehouse_kbn_1_1" name="storehouse_kbn_1" value="2" /> <label for="form_storehouse_kbn_1_1">倉庫に入れる</label>


DEBUG - 2016-03-18 18:37:44 --> 
DEBUG - 2016-03-18 18:37:44 --> 
DEBUG - 2016-03-18 18:37:44 --> <input type="text" size="10" value="" id="form_mall_postage_1" name="mall_postage_1" />

DEBUG - 2016-03-18 18:37:44 --> 
