<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-03-17 12:22:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 12:22:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 12:22:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 12:22:42 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2016-03-17 12:22:43 --> 1
DEBUG - 2016-03-17 12:22:43 --> 2
DEBUG - 2016-03-17 12:22:43 --> 3
DEBUG - 2016-03-17 12:22:43 --> 4
DEBUG - 2016-03-17 12:22:43 --> 5
DEBUG - 2016-03-17 12:22:43 --> 6
DEBUG - 2016-03-17 12:22:43 --> 7
DEBUG - 2016-03-17 12:22:43 --> 8
DEBUG - 2016-03-17 12:22:43 --> 9
DEBUG - 2016-03-17 12:22:43 --> 10
DEBUG - 2016-03-17 12:22:43 --> 11
DEBUG - 2016-03-17 12:22:43 --> 12
DEBUG - 2016-03-17 12:22:43 --> 13
DEBUG - 2016-03-17 12:22:43 --> 14
DEBUG - 2016-03-17 12:22:43 --> 15
DEBUG - 2016-03-17 12:22:43 --> 16
DEBUG - 2016-03-17 12:22:43 --> 17
DEBUG - 2016-03-17 12:22:43 --> 18
DEBUG - 2016-03-17 12:22:43 --> 19
DEBUG - 2016-03-17 12:22:43 --> 20
WARNING - 2016-03-17 12:59:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 12:59:19 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 12:59:19 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 12:59:19 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 12:59:20 --> Notice - Trying to get property of non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 212
WARNING - 2016-03-17 13:04:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:04:18 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:04:18 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:04:18 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:04:18 --> Fatal Error - Call to a member function input() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 212
WARNING - 2016-03-17 13:05:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:05:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:05:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:05:22 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 13:06:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:06:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:06:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:06:00 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 13:07:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:07:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:07:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:07:12 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 13:09:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:09:29 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:09:29 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:09:29 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:09:30 --> Fatal Error - Call to a member function input() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 214
WARNING - 2016-03-17 13:09:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:09:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:09:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:09:33 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:09:34 --> Fatal Error - Call to a member function input() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 214
WARNING - 2016-03-17 13:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:09:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:09:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:09:40 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:09:41 --> Fatal Error - Call to a member function input() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 214
WARNING - 2016-03-17 13:09:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:09:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:09:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:09:56 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 13:10:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:10:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:10:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:10:12 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:10:12 --> Parsing Error - syntax error, unexpected '$fieldset' (T_VARIABLE) in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 1
WARNING - 2016-03-17 13:10:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:10:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:10:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:10:26 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 13:11:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:11:11 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:11:11 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:11:11 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:11:12 --> Fatal Error - Call to a member function input() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 212
WARNING - 2016-03-17 13:13:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:13:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:13:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:13:09 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:13:10 --> Fatal Error - Call to a member function input() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 212
WARNING - 2016-03-17 13:14:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:14:40 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:14:40 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:14:40 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 13:17:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:17:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:17:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:17:47 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 13:17:47 --> Notice - Trying to get property of non-object in C:\Apache2\htdocs\sgq\fuel\app\views\item\create2.php on line 212
WARNING - 2016-03-17 13:18:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:18:39 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:18:39 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:18:39 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 13:22:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 13:22:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 13:22:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 13:22:41 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 14:10:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 14:10:13 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 14:10:13 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 14:10:13 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 14:45:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 14:45:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 14:45:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 14:45:20 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 14:58:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 14:58:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 14:58:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 14:58:06 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:11:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:11:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:11:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:11:09 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:11:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:11:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:11:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:11:33 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:11:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:11:36 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:11:36 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:11:36 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:16:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:16:30 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:16:30 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:16:30 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 15:16:30 --> Fatal Error - Call to a member function find() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 428
WARNING - 2016-03-17 15:18:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:18:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:18:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:18:16 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:19:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:19:21 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:19:21 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:19:21 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:21:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:21:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:21:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:21:53 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:28:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:28:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:28:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:28:20 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:28:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:28:43 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:28:43 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:28:43 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:34:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:34:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:34:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:34:09 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:35:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:35:09 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:35:09 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:35:09 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:43:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:43:47 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:43:47 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:43:47 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:50:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:50:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:50:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:50:00 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:50:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:50:42 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:50:42 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:50:42 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:53:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:53:35 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:53:35 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:53:35 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:54:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:54:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:54:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:54:34 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:54:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:54:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:54:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:54:56 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 15:54:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 15:54:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 15:54:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 15:54:58 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 16:49:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 16:49:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 16:49:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 16:49:16 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 16:49:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 16:49:20 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 16:49:20 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 16:49:20 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 16:49:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 16:49:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 16:49:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 16:49:22 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 16:49:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 16:49:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 16:49:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 16:49:34 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 16:50:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 16:50:03 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 16:50:03 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 16:50:03 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 17:09:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 17:09:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 17:09:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 17:09:31 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 17:09:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 17:09:33 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 17:09:33 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 17:09:33 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 17:10:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 17:10:00 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 17:10:00 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 17:10:00 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 17:10:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 17:10:14 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 17:10:14 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 17:10:14 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 17:11:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 17:11:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 17:11:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 17:11:22 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 17:11:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 17:11:41 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 17:11:41 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 17:11:41 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:06:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:06:52 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:06:52 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:06:52 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:06:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:06:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:06:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:06:54 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:07:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:07:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:07:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:07:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:07:23 --> Notice - Array to string conversion in C:\Apache2\htdocs\sgq\fuel\app\classes\model\itemmall.php on line 241
WARNING - 2016-03-17 18:08:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:08:54 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:08:54 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:08:54 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:08:54 --> Notice - Array to string conversion in C:\Apache2\htdocs\sgq\fuel\app\classes\model\itemmall.php on line 249
WARNING - 2016-03-17 18:09:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:09:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:09:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:09:06 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:09:06 --> Notice - Array to string conversion in C:\Apache2\htdocs\sgq\fuel\app\classes\model\itemmall.php on line 249
WARNING - 2016-03-17 18:09:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:09:22 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:09:22 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:09:22 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:09:23 --> Notice - Undefined index: form in C:\Apache2\htdocs\sgq\fuel\app\classes\model\itemmall.php on line 235
WARNING - 2016-03-17 18:10:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:10:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:10:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:10:27 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:10:27 --> Notice - Undefined index: data_type in C:\Apache2\htdocs\sgq\fuel\app\classes\model\itemmall.php on line 247
WARNING - 2016-03-17 18:12:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:12:05 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:12:05 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:12:05 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:12:06 --> Notice - Undefined variable: itemmall in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 472
WARNING - 2016-03-17 18:12:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:12:46 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:12:46 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:12:46 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:12:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:12:53 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:12:53 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:12:53 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:14:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:14:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:14:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:14:45 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:16:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:16:24 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:16:24 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:16:24 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:16:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:16:26 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:16:26 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:16:26 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:16:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:16:58 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:16:58 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:16:58 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:17:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:17:37 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:17:37 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:17:37 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:33:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:33:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:33:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:33:10 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:33:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:33:12 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:33:12 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:33:12 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:33:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:33:32 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:33:32 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:33:32 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:33:32 --> Notice - Undefined variable: itemmall_1 in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 453
WARNING - 2016-03-17 18:34:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:34:10 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:34:10 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:34:10 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:34:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:34:23 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:34:23 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:34:23 --> Fuel\Core\Request::execute - Setting main Request
ERROR - 2016-03-17 18:34:23 --> Notice - Undefined variable: itemmall_1 in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 454
WARNING - 2016-03-17 18:34:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:34:34 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:34:34 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:34:34 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:34:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:34:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:34:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:34:45 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:35:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:35:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:35:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:35:27 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:35:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:35:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:35:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:35:38 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:35:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:35:45 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:35:45 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:35:45 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:36:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:36:56 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:36:56 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:36:56 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:37:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:37:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:37:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:37:06 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:37:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:37:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:37:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:37:55 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:44:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:44:55 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:44:55 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:44:55 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:46:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:46:06 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:46:06 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:46:06 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:46:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:46:16 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:46:16 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:46:16 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:46:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:46:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:46:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:46:27 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:55:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:55:27 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:55:27 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:55:27 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:55:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:55:38 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:55:38 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:55:38 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:58:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:58:31 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:58:31 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:58:31 --> Fuel\Core\Request::execute - Setting main Request
WARNING - 2016-03-17 18:58:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
INFO - 2016-03-17 18:58:44 --> Fuel\Core\Request::__construct - Creating a new main Request with URI = "item/create2"
INFO - 2016-03-17 18:58:44 --> Fuel\Core\Request::execute - Called
INFO - 2016-03-17 18:58:44 --> Fuel\Core\Request::execute - Setting main Request
DEBUG - 2016-03-17 18:58:44 --> 1
DEBUG - 2016-03-17 18:58:44 --> 2
DEBUG - 2016-03-17 18:58:44 --> 3
DEBUG - 2016-03-17 18:58:44 --> 4
DEBUG - 2016-03-17 18:58:44 --> 5
DEBUG - 2016-03-17 18:58:44 --> 6
DEBUG - 2016-03-17 18:58:44 --> 7
DEBUG - 2016-03-17 18:58:44 --> 8
DEBUG - 2016-03-17 18:58:44 --> 9
DEBUG - 2016-03-17 18:58:44 --> 10
DEBUG - 2016-03-17 18:58:44 --> 11
DEBUG - 2016-03-17 18:58:44 --> 12
DEBUG - 2016-03-17 18:58:44 --> 13
DEBUG - 2016-03-17 18:58:44 --> 14
DEBUG - 2016-03-17 18:58:44 --> 15
DEBUG - 2016-03-17 18:58:44 --> 16
DEBUG - 2016-03-17 18:58:44 --> 17
DEBUG - 2016-03-17 18:58:44 --> 18
DEBUG - 2016-03-17 18:58:44 --> 19
DEBUG - 2016-03-17 18:58:44 --> 20
DEBUG - 2016-03-17 18:58:44 --> 21
DEBUG - 2016-03-17 18:58:44 --> 22
