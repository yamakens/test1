<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-03-03 15:10:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:11:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:11:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:11:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:11:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:11:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:11:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:11:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:13:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:13:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:21:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:21:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 15:21:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 16:17:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-03 16:17:54 --> Error - SQLSTATE[HY000]: General error: 1366 Incorrect integer value: '' for column 'list_price' at row 1 with query: "INSERT INTO `item` (`item_cd`, `item_name`, `brand_name`, `tc_category`, `shop_category1`, `shop_category_code1`, `shop_category2`, `shop_category_code2`, `shop_category3`, `shop_category_code3`, `shop_category4`, `shop_category_code4`, `shop_category5`, `shop_category_code5`, `item_category`, `item_category_code`, `list_price`, `is_open_price`, `base_price`, `latest_pur_price`, `stock_type`, `item_description_title`, `system_item_cd`, `create_member_name`, `update_member_name`, `created_at`, `updated_at`) VALUES ('あああ', 'いいい', 'ううう', 'えええ', 'おおお', 'かかっか', '', '', '', '', '', '', '', '', '', '', '', null, '', '', '0', '', 'あああ', 'いいい', 'ううう', 1456989474, null)" in C:\Apache2\htdocs\sgq\fuel\core\classes\database\pdo\connection.php on line 272
WARNING - 2016-03-03 18:00:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:00:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:01:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:02:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:03:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:03:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:13:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:21:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:21:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:21:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:28:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-03 18:28:57 --> Notice - Undefined variable: content in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 100
WARNING - 2016-03-03 18:29:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-03 18:29:03 --> Notice - Undefined variable: content in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 100
WARNING - 2016-03-03 18:29:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-03 18:29:23 --> Notice - Undefined variable: data in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 102
WARNING - 2016-03-03 18:29:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:43:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:44:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:46:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-03 18:46:34 --> Notice - Undefined variable: content in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 100
WARNING - 2016-03-03 18:46:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:51:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 18:52:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:01:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:01:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:02:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:04:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-03 19:04:44 --> Parsing Error - syntax error, unexpected ',' in C:\Apache2\htdocs\sgq\fuel\app\views\item\create.php on line 43
WARNING - 2016-03-03 19:06:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:06:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:06:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:08:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-03 19:11:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
