<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-03-09 12:10:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 12:10:01 --> Notice - Use of undefined constant STOCK_FREE - assumed 'STOCK_FREE' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 160
WARNING - 2016-03-09 12:10:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 12:10:09 --> Notice - Use of undefined constant STOCK_FREE - assumed 'STOCK_FREE' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 160
WARNING - 2016-03-09 12:12:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 12:12:18 --> Notice - Use of undefined constant STOCK_FREE - assumed 'STOCK_FREE' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 160
WARNING - 2016-03-09 12:12:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 12:13:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 12:13:16 --> Notice - Use of undefined constant STOCK_FREE - assumed 'STOCK_FREE' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 160
WARNING - 2016-03-09 12:21:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 12:21:56 --> Notice - Use of undefined constant STOCK_FREE - assumed 'STOCK_FREE' in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 12
WARNING - 2016-03-09 12:22:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 12:22:33 --> Fatal Error - Call to undefined function definet() in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 14
WARNING - 2016-03-09 12:22:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 12:23:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 12:24:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 12:25:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 14:49:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 14:49:55 --> Fatal Error - "static::" is not allowed in compile-time constants in C:\Apache2\htdocs\sgq\fuel\app\classes\model\item.php on line 159
WARNING - 2016-03-09 14:50:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 14:50:35 --> Notice - Use of undefined constant STOCK_FREE - assumed 'STOCK_FREE' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 160
WARNING - 2016-03-09 14:51:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 14:51:14 --> Parsing Error - syntax error, unexpected '$this' (T_VARIABLE), expecting ')' in C:\Apache2\htdocs\sgq\fuel\app\classes\model\item.php on line 159
WARNING - 2016-03-09 14:57:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 14:57:13 --> Notice - Use of undefined constant STOCK_FREE_LABEL - assumed 'STOCK_FREE_LABEL' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 160
WARNING - 2016-03-09 14:57:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 14:57:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 14:58:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 14:59:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 15:00:00 --> Notice - Use of undefined constant STOCK_FREE_LABEL - assumed 'STOCK_FREE_LABEL' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 142
WARNING - 2016-03-09 15:00:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 15:00:31 --> Fatal Error - "static::" is not allowed in compile-time constants in C:\Apache2\htdocs\sgq\fuel\app\classes\model\item.php on line 159
WARNING - 2016-03-09 15:01:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 15:01:45 --> Fatal Error - "static::" is not allowed in compile-time constants in C:\Apache2\htdocs\sgq\fuel\app\classes\model\item.php on line 159
WARNING - 2016-03-09 15:02:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 15:02:03 --> Notice - Use of undefined constant STOCK_FREE_LABEL - assumed 'STOCK_FREE_LABEL' in C:\Apache2\htdocs\sgq\fuel\packages\orm\classes\model.php on line 142
WARNING - 2016-03-09 15:10:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 15:10:31 --> Fatal Error - "static::" is not allowed in compile-time constants in C:\Apache2\htdocs\sgq\fuel\app\classes\model\item.php on line 159
WARNING - 2016-03-09 15:15:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:22:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 15:22:09 --> Parsing Error - syntax error, unexpected '[' in C:\Apache2\htdocs\sgq\fuel\app\classes\model\item.php on line 238
WARNING - 2016-03-09 15:22:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:24:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:25:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:28:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:28:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:29:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:35:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:36:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:36:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:37:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:37:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:37:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:37:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:44:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 15:56:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:17:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:17:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:17:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:17:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:18:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:18:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:19:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:20:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:21:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:21:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:21:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:21:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:26:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:31:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:32:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:32:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:34:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:35:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:40:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:40:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:41:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:41:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:42:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 17:45:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 17:45:11 --> Notice - Array to string conversion in C:\Apache2\htdocs\sgq\fuel\app\views\template.php on line 35
WARNING - 2016-03-09 18:13:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 18:13:30 --> Notice - Array to string conversion in C:\Apache2\htdocs\sgq\fuel\app\views\template.php on line 35
WARNING - 2016-03-09 18:15:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 18:15:20 --> Error - The requested view could not be found: item/delete.php in C:\Apache2\htdocs\sgq\fuel\core\classes\view.php on line 398
WARNING - 2016-03-09 18:16:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:30:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 18:30:51 --> Notice - Undefined variable: title in C:\Apache2\htdocs\sgq\fuel\app\views\template.php on line 5
WARNING - 2016-03-09 18:32:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:33:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:33:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:34:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 18:34:05 --> Notice - Undefined variable: title in C:\Apache2\htdocs\sgq\fuel\app\views\template.php on line 5
WARNING - 2016-03-09 18:34:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:34:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:35:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:35:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:43:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:43:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:43:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:43:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:43:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:51:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:51:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:51:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 18:51:53 --> Notice - Undefined variable: ids in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 351
WARNING - 2016-03-09 18:52:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 18:52:45 --> Fatal Error - Call to a member function delete() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 355
WARNING - 2016-03-09 18:53:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:53:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:54:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:54:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:55:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 18:55:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-03-09 18:55:10 --> Fatal Error - Call to a member function delete() on a non-object in C:\Apache2\htdocs\sgq\fuel\app\classes\controller\item.php on line 355
WARNING - 2016-03-09 19:01:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:01:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:01:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:02:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:03:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:03:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:03:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:03:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:03:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:14:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:14:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:15:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:15:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:15:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:15:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:16:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-03-09 19:17:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
