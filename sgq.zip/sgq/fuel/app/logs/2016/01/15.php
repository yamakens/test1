<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-01-15 16:23:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-01-15 16:23:14 --> 1045 - SQLSTATE[HY000] [1045] Access denied for user 'fuel_app'@'localhost' (using password: YES) in C:\Apache2\htdocs\sgq\fuel\core\classes\database\pdo\connection.php on line 112
WARNING - 2016-01-15 16:23:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 16:24:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 17:10:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 17:10:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 17:21:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 17:24:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 17:25:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 17:27:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 18:23:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 18:25:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 18:25:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2016-01-15 18:25:56 --> 42 - SQLSTATE[42S02]: Base table or view not found: 1146 Table 'sgq_db.items' doesn't exist with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`item_cd` AS `t0_c1`, `t0`.`item_name` AS `t0_c2`, `t0`.`brand_name` AS `t0_c3`, `t0`.`tc_category` AS `t0_c4`, `t0`.`shop_category1` AS `t0_c5`, `t0`.`shop_category_code1` AS `t0_c6`, `t0`.`shop_category2` AS `t0_c7`, `t0`.`shop_category_code2` AS `t0_c8`, `t0`.`shop_category3` AS `t0_c9`, `t0`.`shop_category_code3` AS `t0_c10`, `t0`.`shop_category4` AS `t0_c11`, `t0`.`shop_category_code4` AS `t0_c12`, `t0`.`shop_category5` AS `t0_c13`, `t0`.`shop_category_code5` AS `t0_c14`, `t0`.`item_category` AS `t0_c15`, `t0`.`item_category_code` AS `t0_c16`, `t0`.`list_price` AS `t0_c17`, `t0`.`is_open_price` AS `t0_c18`, `t0`.`base_price` AS `t0_c19`, `t0`.`latest_pur_price` AS `t0_c20`, `t0`.`stock_type` AS `t0_c21`, `t0`.`item_description_title` AS `t0_c22`, `t0`.`system_item_cd` AS `t0_c23`, `t0`.`create_member_name` AS `t0_c24`, `t0`.`update_member_name` AS `t0_c25`, `t0`.`created_at` AS `t0_c26`, `t0`.`updated_at` AS `t0_c27` FROM `items` AS `t0`" in C:\Apache2\htdocs\sgq\fuel\core\classes\database\pdo\connection.php on line 272
WARNING - 2016-01-15 18:26:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 18:26:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 18:27:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-15 18:27:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
