<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2016-01-28 12:29:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-28 14:58:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-28 14:58:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-28 14:59:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2016-01-28 15:21:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
