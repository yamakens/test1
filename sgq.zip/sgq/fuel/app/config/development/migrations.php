<?php
return array (
  'version' => 
  array (
    'app' => 
    array (
      'default' => 
      array (
        0 => '001_create_item',
        1 => '002_create_itemmall',
        2 => '003_create_itemselect',
        3 => '004_create_image',
        4 => '005_create_mall',
        5 => '006_add_wight_to_item',
        6 => '007_add_mall_postage_to_itemmall',
        7 => '008_add_shipping_method_to_item',
        8 => '009_add_select_horizontal_title_to_item',
        9 => '010_delete_horizontal_title_from_itemselect',
        10 => '011_delete_horizontal_no_from_itemselect',
        11 => '012_add_horizontal_no_to_itemselect',
      ),
    ),
    'module' => 
    array (
    ),
    'package' => 
    array (
    ),
  ),
  'folder' => 'migrations/',
  'table' => 'migration',
);
