<?php
return array (
  'crypto_key' => 'UIcriQ1i4qZAzKoeiU9sg11k',
  'crypto_iv' => 'Z0U3aos_8WWszMoPEIhMs95s',
  'crypto_hmac' => 'ZTUEWIWo0ILMaSEf9glzsbSY',
);
