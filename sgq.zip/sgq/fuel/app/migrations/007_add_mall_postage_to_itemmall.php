<?php

namespace Fuel\Migrations;

class Add_mall_postage_to_itemmall
{
	public function up()
	{
		\DBUtil::add_fields('itemmall', array(
			'mall_postage' => array('constraint' => 5, 'type' => 'int', 'null' => true),

		));
	}

	public function down()
	{
		\DBUtil::drop_fields('itemmall', array(
			'mall_postage'

		));
	}
}