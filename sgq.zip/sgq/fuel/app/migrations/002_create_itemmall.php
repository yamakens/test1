<?php

namespace Fuel\Migrations;

class Create_itemmall
{
	public function up()
	{
		\DBUtil::create_table('itemmall', array(
			'id' => array('constraint' => 11, 'type' => 'int', 'auto_increment' => true, 'unsigned' => true),
			'item_id' => array('constraint' => 6, 'type' => 'int'),
			'mall_id' => array('constraint' => 2, 'type' => 'int'),
			'mall_item_name' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'is_output' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'is_output_category1' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'is_output_category2' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'is_output_category3' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'is_output_category4' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'is_output_category5' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'sale_price' => array('constraint' => 8, 'type' => 'int', 'null' => true),
			'sale_price_rate' => array('constraint' => 2, 'type' => 'int', 'null' => true),
			'tax_kbn' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'postage_kbn' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'sales_period_date_from' => array('type' => 'date', 'null' => true),
			'sales_period_time_from' => array('constraint' => 2, 'type' => 'int', 'null' => true),
			'sales_period_date_to' => array('type' => 'date', 'null' => true),
			'sales_period_time_to' => array('constraint' => 2, 'type' => 'int', 'null' => true),
			'is_order_limit' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'is_order_limit_qty' => array('constraint' => 3, 'type' => 'int', 'null' => true),
			'stock_qty' => array('constraint' => 3, 'type' => 'int', 'null' => true),
			'reserve_qty' => array('constraint' => 3, 'type' => 'int', 'null' => true),
			'category' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'category_id' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),
			'storehouse_kbn' => array('constraint' => 1, 'type' => 'int', 'null' => true),
			'created_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),
			'updated_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),

		), array('id'));
	}

	public function down()
	{
		\DBUtil::drop_table('itemmall');
	}
}