<?php

namespace Fuel\Migrations;

class Add_select_horizontal_title_to_item
{
	public function up()
	{
		\DBUtil::add_fields('item', array(
			'select_horizontal_title' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),
			'select_vertical_title' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),

		));
	}

	public function down()
	{
		\DBUtil::drop_fields('item', array(
			'select_horizontal_title'
,			'select_vertical_title[50]'

		));
	}
}