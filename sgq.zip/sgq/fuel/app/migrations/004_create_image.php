<?php

namespace Fuel\Migrations;

class Create_image
{
	public function up()
	{
		\DBUtil::create_table('image', array(
			'id' => array('constraint' => 11, 'type' => 'int', 'auto_increment' => true, 'unsigned' => true),
			'item_id' => array('constraint' => 6, 'type' => 'int'),
			'image_seq' => array('constraint' => 2, 'type' => 'int'),
			'image_url' => array('constraint' => 200, 'type' => 'varchar'),
			'created_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),
			'updated_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),

		), array('id'));
	}

	public function down()
	{
		\DBUtil::drop_table('image');
	}
}