<?php

namespace Fuel\Migrations;

class Add_wight_to_item
{
	public function up()
	{
		\DBUtil::add_fields('item', array(
			'weight' => array('constraint' => 3, 'type' => 'int', 'null' => true),
			'male_possible' => array('constraint' => 1, 'type' => 'int'),
			'bundle_impossible' => array('constraint' => 1, 'type' => 'int'),
			'same_day_shipping' => array('constraint' => 1, 'type' => 'int'),

		));
	}

	public function down()
	{
		\DBUtil::drop_fields('item', array(
			'weight'
,			'male_possible'
,			'bundle_impossible'
,			'same_day_shipping'

		));
	}
}