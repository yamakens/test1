<?php

namespace Fuel\Migrations;

class Create_item
{
	public function up()
	{
		\DBUtil::create_table('item', array(
			'id' => array('constraint' => 11, 'type' => 'int', 'auto_increment' => true, 'unsigned' => true),
			'item_cd' => array('constraint' => 100, 'type' => 'varchar'),
			'item_name' => array('constraint' => 300, 'type' => 'varchar'),
			'brand_name' => array('constraint' => 100, 'type' => 'varchar'),
			'tc_category' => array('constraint' => 100, 'type' => 'varchar'),
			'shop_category1' => array('constraint' => 300, 'type' => 'varchar'),
			'shop_category_code1' => array('constraint' => 50, 'type' => 'varchar'),
			'shop_category2' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'shop_category_code2' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),
			'shop_category3' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'shop_category_code3' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),
			'shop_category4' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'shop_category_code4' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),
			'shop_category5' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'shop_category_code5' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),
			'item_category' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'item_category_code' => array('constraint' => 50, 'type' => 'varchar', 'null' => true),
			'list_price' => array('constraint' => 8, 'type' => 'int', 'null' => true),
			'is_open_price' => array('constraint' => 1, 'type' => 'int'),
			'base_price' => array('constraint' => 8, 'type' => 'int', 'null' => true),
			'latest_pur_price' => array('constraint' => 8, 'type' => 'int', 'null' => true),
			'stock_type' => array('constraint' => 1, 'type' => 'int'),
			'item_description_title' => array('constraint' => 300, 'type' => 'varchar', 'null' => true),
			'system_item_cd' => array('constraint' => 100, 'type' => 'varchar'),
			'create_member_name' => array('constraint' => 50, 'type' => 'varchar'),
			'update_member_name' => array('constraint' => 50, 'type' => 'varchar'),
			'created_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),
			'updated_at' => array('constraint' => 11, 'type' => 'int', 'null' => true),

		), array('id'));
	}

	public function down()
	{
		\DBUtil::drop_table('item');
	}
}