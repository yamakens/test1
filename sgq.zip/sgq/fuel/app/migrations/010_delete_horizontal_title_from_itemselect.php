<?php

namespace Fuel\Migrations;

class Delete_horizontal_title_from_itemselect
{
	public function up()
	{
		\DBUtil::drop_fields('itemselect', array(
			'horizontal_title'
,			'vertical_title'

		));
	}

	public function down()
	{
		\DBUtil::add_fields('itemselect', array(
			'horizontal_title' => array('constraint' => 100, 'type' => 'varchar'),
			'vertical_title' => array('constraint' => 100, 'type' => 'varchar'),

		));
	}
}