<?php

namespace Fuel\Migrations;

class Delete_horizontal_no_from_itemselect
{
	public function up()
	{
		\DBUtil::drop_fields('itemselect', array(
			'horizontal_no'
,			'vertical_no'

		));
	}

	public function down()
	{
		\DBUtil::add_fields('itemselect', array(
			'horizontal_no' => array('constraint' => 2, 'type' => 'int'),
			'vertical_no' => array('constraint' => 2, 'type' => 'int'),

		));
	}
}