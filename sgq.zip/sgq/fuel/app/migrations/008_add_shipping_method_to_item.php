<?php

namespace Fuel\Migrations;

class Add_shipping_method_to_item
{
	public function up()
	{
		\DBUtil::add_fields('item', array(
			'shipping_method' => array('constraint' => 2, 'type' => 'int'),

		));
	}

	public function down()
	{
		\DBUtil::drop_fields('item', array(
			'shipping_method'

		));
	}
}