<div id="content">
<h1>商品登録（<?php echo $item_cd ?>）商品の登録を行います。</h1>
<h2>基本情報</h2>
<form id="form1" name="form1" method="post" action="">
<table class="t1">
  <tr>
    <th scope="row"><?php echo  $fieldset->field('item_name')->label; ?></th>
    <td>
      <?php echo $fieldset->field('item_name')->build(); ?>
    </td>
  </tr>
  <?php foreach($malls as $m):?>
  <tr>
    <th scope="row"><?=$m->mall_short_name?></th>
    <td><?php echo $fieldset->field('mall_item_name_' . $m->id)->build(); ?></td>
  </tr>
  <?php  endforeach;?>
</table>
<h2>店舗別カテゴリ・ID設定</h2>
<table class="t1">
  <tr>
    <th scope="row"><?php echo $fieldset->field('brand_name')->label ?></th>
    <td><?php echo $fieldset->field('brand_name')->build() ?>
  </tr>
  <tr>
    <th scope="row"><?php echo $fieldset->field('tc_category')->label ?></th>
    <td><?php echo $fieldset->field('tc_category')->build() ?>
  </tr>
  <?php for($i=1;$i<=5;$i++):?>
  <tr>
    <th scope="row"><?php echo $fieldset->field('shop_category'.$i)->label; ?></th>
    <td><input type="button" name="button2" id="button2" value="選択" />
      <?php echo $fieldset->field('shop_category'.$i)->build(); ?>
      <?php echo $fieldset->field('shop_category_code'.$i)->build(); ?>
      <a href="#">削除</a></td>
  </tr>
  <?php endfor;?>
  <tr>
    <th scope="row"><?php echo $fieldset->field('item_category')->label; ?></th>
    <td><input type="button" name="button2" id="button2" value="選択" />
      <?php echo $fieldset->field('item_category')->build(); ?>
      <?php echo $fieldset->field('item_category_code')->build(); ?><a href="#">削除</a><br />
    </td>
  </tr>
</table>

<table class="t1">
  <?php $th_flg = true; ?>
  <?php foreach($malls as $m): ?>
  <tr>
    <?php if($th_flg):?>
    <th scope="row" rowspan="10" style="vertical-align:top;padding-top:5px;">書出し先</th>
    <?php endif;?>
    <td><?php echo $fieldset->field('is_output_'.$m->id)->build();?>
        <?php echo $m->mall_short_name;?>
    </td>
    <?php if($th_flg):?>
    <th scope="row" rowspan="10" style="vertical-align:top;padding-top:5px;">店舗内カテゴリ出力</th>
    <?php $th_flg = false;?>
    <?php endif; ?>
    <td><?php echo $m->mall_short_name;?></td>
    <td><a href="#">[全選択]</a><a href="#">[全解除]</a>
      <?php for($i=1;$i<=5;$i++):?>
        <?php echo $fieldset->field('is_output_category'.$i.'_'.$m->id)->build();?>
        <label><?php echo $i?></label>
      <?php endfor;?>
    </td>
  </tr>
  <?php endforeach;?>
</table>
<table class="t1">
  <tr>
    <th scope="row"><?php echo $fieldset->field('list_price')->label ?></th>
    <td><?php echo $fieldset->field('list_price')->build(); ?>円（税抜き）
        <?php echo $fieldset->field('is_open_price')->build();?>
        <?php echo $fieldset->field('is_open_price')->label;?>
      </td>
  </tr>
  <tr>
    <th scope="row"><?php echo $fieldset->field('latest_pur_price')->label ?></th>
    <td><?php echo $fieldset->field('latest_pur_price')->build() ?>円
  </td>
  </tr>
  <tr>
    <th scope="row"><?php echo $fieldset->field('base_price')->label ?></th>
    <td><?php echo $fieldset->field('base_price')->build() ?>円
  </td>
  </tr>
</table>

<h2>販売価格</h2>
<table class="t1">
  <?php foreach($malls as $m):?>
  <tr>
    <th scope="row"><?php echo $m->mall_short_name ?></th>
    <td><?php echo $fieldset->field('sale_price_'.$m->id)->build();?>円</td>
    <td><?php echo $fieldset->field('tax_kbn_'.$m->id)->build();?></td>
    <td><?php echo $fieldset->field('sale_price_rate_'.$m->id)->build()?>
  </tr>
  <?php endforeach?>
</table>

<h2>送料</h2>
<table class="t1">
  <?php foreach($malls as $m):?>
  <tr>
    <th scope="row"><?php echo $m->mall_short_name?></th>
    <td><?php echo $fieldset->field('postage_kbn_'.$m->id)->build();?></td>
    <td><?php echo $fieldset->field('mall_postage_'.$m->id)->label,'　', $fieldset->field('mall_postage_'.$m->id)->build()?> 円</td>
  </tr>
  <?php endforeach;?>
</table>

<h2>販売期間</h2>
<table class="t1">
  <?php foreach($malls as $m): ?>
  <tr>
    <th scope="row"><?php echo $m->mall_short_name?></th>
    <td><?php echo $fieldset->field('sales_period_date_from_'.$m->id)->build()?>
        <?php echo $fieldset->field('sales_period_time_from_'.$m->id)->build()?>時00分～
        <?php echo $fieldset->field('sales_period_date_to_'.$m->id)->build()?>
        <?php echo $fieldset->field('sales_period_time_to_'.$m->id)->build()?>時59分</td>
  </tr>
  <?php endforeach;?>
</table>

<h2>購入数制限</h2>
<table class="t1">
  <?php foreach($malls as $m):?>
  <tr>
    <th scope="row"><?php echo $m->mall_short_name?></th>
    <td><?php echo $fieldset->field('is_order_limit_'.$m->id)->build()?>　
    <?php echo $fieldset->field('is_order_limit_qty_'.$m->id)->build()?>個</td>
  </tr>
  <?php endforeach;?>
</table>

<h2>在庫設定</h2>
<table class="t1">
  <tr>
    <th scope="row" rowspan="2" style="vertical-align:top;padding-top:5px;" ><?php echo $fieldset->field('stock_type')->label?></th>
    <td><?php echo $fieldset->field('stock_type')->build()?></td>
  </tr>
  <tr>
    <td>
      <div style="width:50%;float:right;">
      <p>
        <?php echo $fieldset->field('select_horizontal_title')->label?>
        <?php echo $fieldset->field('select_horizontal_title')->build()?>
      </p>
      <div style="width:100%;">
      <table class="tsel">
        <tr>
          <th scope="col">#</th>
          <th scope="col">枝番号</th>
          <th scope="col">オプション名</th>
        </tr>
        <?php for($i=1;$i<=20;$i++):?>
        <tr>
          <td><?php echo sprintf("%02d",$i)?></td>
          <td><?php echo $fieldset->field('horizontal_no_'.$i)->build() ?></td>
          <td><?php echo $fieldset->field('horizontal_name_'.$i)->build() ?></td>
        </tr>
        <?php endfor;?>
      </table>
      </div>
      </div>
      <div style="width:49%;float:left;">
      <p>
        <?php echo $fieldset->field('select_vertical_title')->label?>
        <?php echo $fieldset->field('select_vertical_title')->build()?>
      </p>
      <div style="width:100%;">
      <table class="tsel">
        <tr>
          <th scope="col">#</th>
          <th scope="col">枝番号</th>
          <th scope="col">オプション名</th>
        </tr>
        <?php for($i=1;$i<=20;$i++):?>
        <tr>
          <td><?php echo sprintf("%02d",$i)?></td>
          <td><?php echo $fieldset->field('vertical_no_'.$i)->build() ?></td>
          <td><?php echo $fieldset->field('vertical_name_'.$i)->build() ?></td>
        </tr>
        <?php endfor;?>
      </table>
      </div>
      </div>
      </td>
  </tr>
</table>
<h2>画像</h2>
<table class="timg">
<?php for($j=0;$j<=1;$j++):?>
  <tr>
  <?php for($i=1;$i<=5;$i++):?>
    <th scope="col">画像<?=$i+($j*5)?></th>
  <?php endfor;?>
  </tr>
  <tr>
  <?php for($i=1;$i<=5;$i++):?>
    <td><div class="center"><input type="button" name="button7" id="button7" value="画像参照" /></div></td>
  <?php endfor;?>
  </tr>
  <tr>
  <?php for($i=1;$i<=5;$i++):?>
    <?php if($fieldset->field('image_url_'.($i+($j*5)))->value ==''):?>
      <td><div class="center"><?php echo Asset::img('noimg.gif'); ?></div></td>
    <?php else:?>
      <td><div class="center"><?php echo Asset::img($fieldset->field('image_url_'.($i+($j*5)))->value); ?></div></td>
    <?php endif;?>
  <?php endfor;?>
  </tr>
  <tr>
  <?php for($i=1;$i<=5;$i++):?>
    <td><div class="center"><a href="#">画像削除</a></div></td>
  <?php endfor;?>
  </tr>
<?php endfor;?>
  </table>
<h2>商品説明</h2>
<table class="t1">
  <tr>
    <th scope="row" style="vertical-align:top;padding-top:5px"><?php echo $fieldset->field('item_description_title')->label;?></th>
    <td><?php echo $fieldset->field('item_description_title')->build();?></td>
  </tr>
</table>

<h2>各種設定</h2>
<table class="t1">
  <tr>
    <th scope="row"><?php echo $fieldset->field('weight')->label?></th>
    <td><?php echo $fieldset->field('weight')->build()?> g</td>
  </tr>
  <tr>
    <th scope="row"><?php echo $fieldset->field('shipping_method')->label?></th>
    <td><?php echo $fieldset->field('shipping_method')->build();?></td>
  </tr>

  <tr>
    <th scope="row"><?php echo $fieldset->field('system_item_cd')->label ?></th>
    <td><?php echo $fieldset->field('system_item_cd')->build() ?></td>
  </tr>
  <tr>
    <th scope="row"><?php echo $fieldset->field('male_possible')->label?></th>
    <td><?php echo $fieldset->field('male_possible')->build()?>
  </tr>
  <tr>
    <th scope="row"><?php echo $fieldset->field('bundle_impossible')->label?></th>
    <td><?php echo $fieldset->field('bundle_impossible')->build()?></td>
  </tr>
  <tr>
    <th scope="row"><?php echo $fieldset->field('same_day_shipping')->label?></th>
    <td><?php echo $fieldset->field('same_day_shipping')->build()?></td>
  </tr>
</table>
<h2>店舗別カテゴリ・ID設定</h2>
<table class="t1">
  <?php foreach($malls as $m):?>
  <tr>
    <th scope="row"><?php echo $m->mall_short_name ?></th>
    <td><input type="button" name="button9" id="button10" value="選択" />
      <?php echo $fieldset->field('category_'.$m->id)->build()?>
      <?php echo $fieldset->field('category_id_'.$m->id)->build()?>
      <a href="#">削除</a></td>
  </tr>
  <?php endforeach;?>
</table>

<h2>倉庫指定</h2>
<table class="t1">
  <?php foreach($malls as $m):?>
  <tr>
    <th scope="row"><?php echo $m->mall_short_name ?></th>
    <td><?php echo $fieldset->field('storehouse_kbn_'.$m->id)->build();?></td>
  </tr>
  <?php endforeach;?>
</table>
<p></p>
<p>
  <input type="submit" name="button10" id="button9" value="この内容で登録をする" />
</p>
</form>
</div>
