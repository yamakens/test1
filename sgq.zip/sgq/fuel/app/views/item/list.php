<form name="itemlist" action="<?php echo Uri::create('item/delete/'); ?>" method="post">
<div style="float:right;"><input type="submit" name="b1" value="チェックしたものを削除"></div>
<table class="table">
<tr>
<th>修正</th>
<th>画像</th>
<th>商品コード</th>
<th>商品名</th>
<th>型番</th>
<th>作成日</th>
<th>チェック</th>
</tr>
<?php foreach ($items as $item): ?>
<tr>
	<td><a href="<?php echo Uri::create('item/edit/' . $item->id); ?>">修正</a></td>
	<td>
	<?php if ($item->image): ?>

	<?php endif; ?>
	</td>
	<td><?php echo $item->item_cd; ?></td>
	<td><a href="<?php echo Uri::create('item/view/' . $item->id); ?>"><?php echo $item->item_name; ?></a></td>
	<td><?php echo $item->system_item_cd; ?></td>
	<td><?php echo date("Y-m-d H:i:s", $item->created_at); ?></td>
	<td><input type="checkbox" name="chk[]" value="<?php echo $item->id ?>"></td>
</tr>
<?php endforeach; ?>
</table>
</form>
<?php echo $pagination ?>
