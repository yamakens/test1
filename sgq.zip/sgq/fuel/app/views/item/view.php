<div>
	<span style="font-weight: bold">商品名：</span>
	<?php echo $item->item_name; ?>
	（<?php echo date("Y-m-d H:i:s", $item->created_at); ?>）<br>
</div>
<hr>
<div class="offset1">
	<div>
		<div>
			<span style="font-weight: bold">店舗内カテゴリ1：</span>
			<?php echo $item->shop_category1; ?>
			（<?php echo $item->shop_category_code1; ?>）
		</div>
		<div>
			<?php if($item->is_open_price): ?>
				オープン価格
			<?php else: ?>
				メーカー希望小売価格<?php echo (int)$item->list_price ?>円
			<?php endif; ?>
		</div>
		<div>
			<span style="font-weight: bold">在庫タイプ：</span>
			<?php echo $item->stock_type_string; ?>
		</div>
		<div>
			<span style="font-weight: bold">基幹システム商品コード：</span>
			<?php echo $item->system_item_cd; ?>
		</div>
		<div>
			<span style="font-weight: bold">作成者：</span><?= $item->create_member_name; ?><br>
			<span style="font-weight: bold">最終更新者：</span><?= $item->update_member_name; ?>
		</div>
		<div>
			<a href="../edit/<?php echo $item->id ?>">編集する</a>
		</div>
		<hr>
	</div>
</div>
