商品データ削除の確認
<form action="" method="post">
<ul>
<?php foreach($items as $item): ?>
<li><?php echo $item->id; ?></li>
<input type="hidden" name="ids[]" value="<?php echo $item->id; ?>">
<?php endforeach;?>
</ul>
<input type="submit" name="b2" value="確認">
</form>