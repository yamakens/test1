<?php

foreach ($fields as $f){

	echo $f->build() . '<br>';
}
?>