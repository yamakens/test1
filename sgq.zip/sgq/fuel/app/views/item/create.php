<!-- フォームの作成  -->
<table>
<?php echo Form::open('item/create'); ?>
<tr>
<td><?php echo Form::label('商品コード','item_cd'); ?></td>
<td><?php echo Form::input('item_cd',$item_cd,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('商品名','item_name'); ?></td>
<td><?php echo Form::input('item_name',$item_name,array('size'=>20)); ?></td>
</tr><tr>
<td><?php echo Form::label('ブランド名','brand_name'); ?></td>
<td><?php echo Form::input('brand_name',$brand_name,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('TCカテゴリ','tc_category'); ?></td>
<td><?php echo Form::input('tc_category',$tc_category,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリ1','shop_category1'); ?></td>
<td><?php echo Form::input('shop_category1',$shop_category1,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリコード1','shop_category_code1'); ?></td>
<td><?php echo Form::input('shop_category_code1',$shop_category_code1,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリ2','shop_category2'); ?></td>
<td><?php echo Form::input('shop_category2',$shop_category2,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリコード2','shop_category_code2'); ?></td>
<td><?php echo Form::input('shop_category_code2',$shop_category_code2,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリ3','shop_category3'); ?></td>
<td><?php echo Form::input('shop_category3',$shop_category3,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリコード3','shop_category_code3'); ?></td>
<td><?php echo Form::input('shop_category_code3',$shop_category_code3,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリ4','shop_category4'); ?></td>
<td><?php echo Form::input('shop_category4',$shop_category4,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリコード4','shop_category_code4'); ?></td>
<td><?php echo Form::input('shop_category_code4',$shop_category_code4,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリ5','shop_category5'); ?></td>
<td><?php echo Form::input('shop_category5',$shop_category5,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('店舗内カテゴリコード5','shop_category_code5'); ?></td>
<td><?php echo Form::input('shop_category_code5',$shop_category_code5,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('商品取得カテゴリ','item_category'); ?></td>
<td><?php echo Form::input('item_category',$item_category,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('商品取得カテゴリコード','item_category_code'); ?></td>
<td><?php echo Form::input('item_category_code',$item_category_code,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('定価','list_price'); ?></td>
<td><?php echo Form::input('list_price',$list_price,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('オープン価格','is_open_price'); ?></td>
<?php if($is_open_price === '1'){
	$is_open_price = ['id' => 'form_is_open_price', 'checked' => ''];
}else{
	$is_open_price = ['id' => 'form_is_open_price' ];
}
?>
<td><?php echo Form::checkbox('is_open_price','1',$is_open_price); ?></td>
</tr><tr>
<td><?php echo Form::label('販売基準価格','base_price'); ?></td>
<td><?php echo Form::input('base_price',$base_price,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('最終仕入れ価格','latest_pur_price'); ?></td>
<td><?php echo Form::input('latest_pur_price',$latest_pur_price,array('size' => 20)); ?></td>
</tr><tr>
<td>在庫タイプ</td>
<td>
<?php
$form_stock_type_1 = ['id' => 'form_stock_type_1'];
$form_stock_type_2 = ['id' => 'form_stock_type_2'];
$form_stock_type_3 = ['id' => 'form_stock_type_3'];
if(isset($stock_type)){
	switch(true){
		case $stock_type === '1':
			$form_stock_type_1 = ['id' => 'form_stock_type_1','checked'=>''];
			break;
		case $stock_type === '2':
			$form_stock_type_2 = ['id' => 'form_stock_type_2','checked'=>''];
			break;
		case $stock_type === '3':
			$form_stock_type_3 = ['id' => 'form_stock_type_3','checked'=>''];
			break;
		default:
	}
}
?>
  <?php echo Form::radio('stock_type','1',$form_stock_type_1), Form::label('設定なし','stock_type_1'); ?>
　<?php echo Form::radio('stock_type','2',$form_stock_type_2), Form::label('通常在庫','stock_type_2'); ?>
　<?php echo Form::radio('stock_type','3',$form_stock_type_3), Form::label('項目選択肢別','stock_type_3'); ?>
</td>
</tr><tr>
<td><?php echo Form::label('商品説明タイトル','item_description_title'); ?></td>
<td><?php echo Form::input('item_description_title',$item_description_title,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('基幹システム商品コード','system_item_cd'); ?></td>
<td><?php echo Form::input('system_item_cd',$system_item_cd,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('作成者','create_member_name'); ?></td>
<td><?php echo Form::input('create_member_name',$create_member_name,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::label('最終更新者','update_member_name'); ?></td>
<td><?php echo Form::input('update_member_name',$update_member_name,array('size' => 20)); ?></td>
</tr><tr>
<td><?php echo Form::submit('submit','登録'); ?></td>
</tr>
</table>
<?php echo Form::close();?>
<?php echo $message; ?>