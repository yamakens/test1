<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>テスト</title>
	<?php echo Asset::css('bootstrap.css'); ?>
	<style>
		body { margin: 40px; }
		.validation_error { background-color:#ffecec; }
	</style>
</head>
<body>
<?php echo $form['open']; ?>

<h2>何歳やねん？</h2>
<table class="table table-bordered">
<tr>
<th class="span2"><?php echo $form['age']['label'];?></th>
<td><?php echo $form['age']['html'];?> 歳</td>
</tr>
</table>

<h2>改行ありのRadio</h2>
<table class="table table-bordered">
<tr>
<th class="span2"><?php echo $form['gender']['label'];?></th>
<td><?php echo $form['gender']['html'];?></td>
</tr>
</table>

<h2>一行のRadio</h2>
<p>
<?php echo $form['season']['html'];?>
</p>

<?php echo $form['close']; ?>
</body></html>