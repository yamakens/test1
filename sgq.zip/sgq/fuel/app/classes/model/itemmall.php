<?php

class Model_Itemmall extends \Orm\Model
{
	protected static $_properties = array(
		'id' => array(),
		'item_id' => array(
				'data_type' => 'int',
				'label' => '商品ID',
				'validation' => array('required','max_length'=>array(6)),
				'form' => array('type' => 'text'),
		),

		'mall_id' => array(
				'data_type' => 'int',
				'label' => 'モールID',
				'validation' => array('required','max_length'=>array(2)),
				'form' => array('type' => 'text'),
		),

		'mall_item_name' => array(
				'data_type' => 'varchar',
				'label' => '個別商品名',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'text', 'size' => 50),
				'null' => true,
		),

		'is_output' => array(
				'data_type' => 'int',
				'label' => '書出し先',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
				'null' => true,
		),

		'is_output_category1' => array(
				'data_type' => 'int',
				'label' => 'チェック1',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
				'null' => true,
		),

		'is_output_category2' => array(
				'data_type' => 'int',
				'label' => 'チェック2',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
				'null' => true,
		),

		'is_output_category3' => array(
				'data_type' => 'int',
				'label' => 'チェック3',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
				'null' => true,
		),

		'is_output_category4' => array(
				'data_type' => 'int',
				'label' => 'チェック4',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
				'null' => true,
		),

		'is_output_category5' => array(
				'data_type' => 'int',
				'label' => 'チェック5',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
				'null' => true,
		),

		'sale_price' => array(
				'data_type' => 'int',
				'label' => '販売価格',
				'validation' => array('max_length'=>array(8)),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'sale_price_rate' => array(
				'data_type' => 'int',
				'label' => '販売価格レート',
				'validation' => array('max_length'=>array(2)),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'tax_kbn' => array(
				'data_type' => 'int',
				'label' => '販売価格税区分',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'radio', 'options'=>array(1=>'税込',2=>'税別')),
				'null' => true,
		),

		'postage_kbn' => array(
				'data_type' => 'int',
				'label' => '送料区分',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'radio', 'options'=>array(1=>'別',2=>'込')),
				'null' => true,
		),

		'sales_period_date_from' => array(
				'data_type' => 'date',
				'label' => '販売開始日',
				'validation' => array(),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'sales_period_time_from' => array(
				'data_type' => 'int',
				'label' => '販売開始時間',
				'validation' => array('max_length'=>array(2)),
				'form' => array('type' => 'select', 'options'=>array(0=>'00',1=>'01',2=>'02',3=>'03',4=>'04',5=>'05',6=>'06',7=>'07',8=>'08',9=>'09',10=>'10',11=>'11',12=>'12',13=>'13',14=>'14',15=>'15',16=>'16',17=>'17',18=>'18',19=>'19',20=>'20',21=>'21',22=>'22',23=>'23')),
				'null' => true,
		),

		'sales_period_date_to' => array(
				'data_type' => 'date',
				'label' => '販売終了日',
				'validation' => array(),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'sales_period_time_to' => array(
				'data_type' => 'int',
				'label' => '販売終了時間',
				'validation' => array('max_length'=>array(2)),
				'form' => array('type' => 'select', 'options'=>array(0=>'00',1=>'01',2=>'02',3=>'03',4=>'04',5=>'05',6=>'06',7=>'07',8=>'08',9=>'09',10=>'10',11=>'11',12=>'12',13=>'13',14=>'14',15=>'15',16=>'16',17=>'17',18=>'18',19=>'19',20=>'20',21=>'21',22=>'22',23=>'23')),
				'null' => true,
		),

		'is_order_limit' => array(
				'data_type' => 'int',
				'label' => '購入制限',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'radio', 'options'=>array(1=>'制限無し(自由入力)',2=>'制限あり')),
				'null' => true,
		),

		'is_order_limit_qty' => array(
				'data_type' => 'int',
				'label' => '購入制限数量',
				'validation' => array('max_length'=>array(2)),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'stock_qty' => array(
				'data_type' => 'int',
				'label' => '通常在庫数',
				'validation' => array('max_length'=>array(3)),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'reserve_qty' => array(
				'data_type' => 'int',
				'label' => '予約在庫数',
				'validation' => array('max_length'=>array(3)),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'category' => array(
				'data_type' => 'varchar',
				'label' => '店舗別カテゴリ',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'category_id' => array(
				'data_type' => 'varchar',
				'label' => '店舗別カテゴリID',
				'validation' => array('max_length'=>array(50)),
				'form' => array('type' => 'text'),
				'null' => true,
		),

		'storehouse_kbn' => array(
				'data_type' => 'int',
				'label' => '倉庫指定',
				'validation' => array('max_length'=>array(1)),
				'form' => array('type' => 'radio','options'=>array(1=>'販売中',2=>'倉庫に入れる')),
				'null' => true,
		),

		'created_at' => array('skip' => true),
		'updated_at' => array('skip' => true),

		'mall_postage' => array(
				'data_type' => 'int',
				'label' => '個別送料',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(5)),
				'form' => array('type' => 'text','size' => 10),
				'null' => true,
		),

	);

	protected static $_observers = array(
		'Orm\Observer_CreatedAt' => array(
			'events' => array('before_insert'),
			'mysql_timestamp' => false,
		),
		'Orm\Observer_UpdatedAt' => array(
			'events' => array('before_update'),
			'mysql_timestamp' => false,
		),
	);
	protected static $_table_name = 'itemmall';
	protected static $_belongs_to = array(
		'item' => array(
			'key_from' => 'item_id',
			'model_to' => 'Model_Item',
			'key_to'   => 'id',
			'cascade_save' => false,
			'cascade_delete' => false,
		)
	);

	public function chk_prop(){

		$i=0;
		foreach ($this::$_properties as $key => $p){

			//チェックボックスは配列で渡されるの巻
			if(isset($p['form']) && $p['form']['type'] === 'checkbox'){
				if(is_array($this->$key)){
					$this->$key = $this->$key[0];
				}else{
					$this->$key = $this->$key;
				}
				if(!ctype_digit($this->$key)){
					$this->$key = null;
				}
				continue;
			}
			//null許可でint型
			if(isset($p['data_type']) && isset($p['data_type']) && $p['data_type'] === 'int' && isset($p['null'])){
				//数字じゃない場合はnullにしてしまう
				if(!ctype_digit($this->$key)){
					$this->$key = null;
				}
			}
		}
	}

	public function save($cascade = NULL, $use_transaction = false){
		$this->chk_prop();
		return parent::save($cascade,$use_transaction);
	}
}
