<?php

class Model_Item extends \Orm\Model
{
	const STOCK_FREE            = 1;
	const STOCK_SINGLE          = 2;
	const STOCK_VARIATION       = 3;
	const STOCK_FREE_LABEL      = '設定なし';
	const STOCK_SINGLE_LABEL    = '通常在庫';
	const STOCK_VARIATION_LABEL = '項目選択肢別';

	const CARRIER_UNSELECTED = 0;
	const CARRIER_YAMATO = 1;
	const CARRIER_YUPACK = 2;
	const CARRIER_SAGAWA = 3;
	const CARRIER_MALE   = 4;
	const CARRIER_UNSELECTED_LABEL = '未選択';
	const CARRIER_YAMATO_LABEL = 'ヤマト運輸';
	const CARRIER_YUPACK_LABEL = 'ゆうパック';
	const CARRIER_SAGAWA_LABEL = '佐川急便';
	const CARRIER_MALE_LABEL   = 'メール便';


	protected static $_properties = array(

		'id',

		'item_cd' => array(
				'data_type' => 'varchar',
				'label' => '商品コード',
				'validation' => array('required','max_length'=>array(100)),
				'form' => array('type' => 'text','size' => '30'),
		),

		'item_name' => array(
				'data_type' => 'varchar',
				'label' => '商品名',
				'validation' => array('required','max_length'=>array(300)),
				'form' => array('type' => 'text', 'size' => 50),
		),

		'brand_name' => array(
				'data_type' => 'varchar',
				'label' => 'ブランド名',
				'validation' => array('required','max_length'=>array(100)),
				'form' => array('type' => 'text'),
		),

		'tc_category' => array(
				'data_type' => 'varchar',
				'label' => 'TCカテゴリ',
				'validation' => array('required','max_length'=>array(100)),
				'form' => array('type' => 'text'),
		),

		'shop_category1' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリ1',
				'validation' => array('required','max_length'=>array(300)),
				'form' => array('type' => 'text'),
		),

		'shop_category_code1' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリコード1',
				'validation' => array('required','max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'shop_category2' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリ2',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'text'),
		),

		'shop_category_code2' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリコード2',
				'validation' => array('max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'shop_category3' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリ3',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'text'),
		),

		'shop_category_code3' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリコード3',
				'validation' => array('max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'shop_category4' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリ4',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'text'),
		),

		'shop_category_code4' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリコード4',
				'validation' => array('max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'shop_category5' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリ5',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'text'),
		),

		'shop_category_code5' => array(
				'data_type' => 'varchar',
				'label' => '店舗内カテゴリコード5',
				'validation' => array('max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'item_category' => array(
				'data_type' => 'varchar',
				'label' => '商品取得カテゴリ',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'text'),
		),

		'item_category_code' => array(
				'data_type' => 'varchar',
				'label' => '商品取得カテゴリコード',
				'validation' => array('max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'list_price' => array(
				'data_type' => 'int',
				'label' => '定価',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(8)),
				'form' => array('type' => 'text'),
		),

		'is_open_price' => array(
				'data_type' => 'int',
				'label' => 'オープン価格',
				'form' => array('type' => 'checkbox', 'options' => array(1 => '')),
		),

		'base_price' => array(
				'data_type' => 'int',
				'label' => '販売基準価格',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(8)),
				'form' => array('type' => 'text'),
		),

		'latest_pur_price' => array(
				'data_type' => 'int',
				'label' => '最終仕入れ金額',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(8)),
				'form' => array('type' => 'text'),
		),

		'stock_type' => array(
				'data_type' => 'int',
				'label' => '在庫タイプ',
				'validation' => array('required'),
				'form' => array('type' => 'radio', 'options' => array(1=>'設定なし',2=>'通常在庫',3=>'項目選択肢別')),
		),

		'item_description_title' => array(
				'data_type' => 'varchar',
				'label' => '商品説明(タイトル)',
				'validation' => array('max_length'=>array(300)),
				'form' => array('type' => 'textarea', 'cols' => 70, 'rows' => 6),
		),

		'system_item_cd' => array(
				'data_type' => 'varchar',
				'label' => '基幹システム商品コード',
				'validation' => array('required','max_length'=>array(100)),
				'form' => array('type' => 'text'),
		),

		'create_member_name' => array(
				'data_type' => 'varchar',
				'label' => '作成者',
				'validation' => array('required','max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'update_member_name' => array(
				'data_type' => 'varchar',
				'label' => '最終更新者',
				'validation' => array('required','max_length'=>array(50)),
				'form' => array('type' => 'text'),
		),

		'created_at' => array(
				'skip' => true),

		'updated_at' => array(
				'skip' => true),

		'weight' => array(
				'data_type' => 'int',
				'label' => '重量',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(3)),
				'form' => array('type' => 'text', 'size' => 10),
		),

		'male_possible' => array(
				'data_type' => 'int',
				'label' => 'メール便対応',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
		),

		'bundle_impossible' => array(
				'data_type' => 'int',
				'label' => '同梱不可',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
		),

		'same_day_shipping' => array(
				'data_type' => 'int',
				'label' => '即日出荷対応',
				'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(1)),
				'form' => array('type' => 'checkbox'),
		),


		'shipping_method' => array(
				'data_type' => 'int',
				'label' => '配送方法',
				'validation' => array('required'),
				'form' => array('type' => 'select', 'options' => array(0=>'未選択',1=>'ヤマト運輸',2=>'ゆうパック',3=>'佐川急便')),
		),

		'select_horizontal_title' => array(
				'data_type' => 'varchar',
				'label' => '横軸タイトル',
				'validation' => array('max_length'=>array(100)),
				'form' => array('type' => 'text'),
		),

		'select_vertical_title' => array(
				'data_type' => 'varchar',
				'label' => '縦軸タイトル',
				'validation' => array('max_length'=>array(100)),
				'form' => array('type' => 'text'),
		),

	);

	protected static $_observers = array(
		'Orm\Observer_CreatedAt' => array(
			'events' => array('before_insert'),
			'mysql_timestamp' => false,
		),
		'Orm\Observer_UpdatedAt' => array(
			'events' => array('before_update'),
			'mysql_timestamp' => false,
		),
	);

	protected static $_table_name = 'item';
	//他のテーブルとのリレーション
	protected static $_has_many = array(
		'itemMall' => array(
			'key_from' => 'id',
			'model_to' => 'Model_Itemmall',
			'key_to'   => 'item_id',
			'cascade_save' => false,
			'cascade_delete' => false,
		),
		'itemSelect' => array(
			'key_from' => 'id',
			'model_to' => 'Model_Itemselect',
			'key_to'   => 'item_id',
			'cascade_save' => false,
			'cascade_delete' => false,
		),
		'image' => array(
			'key_from' => 'id',
			'model_to' => 'Model_Image',
			'key_to'   => 'item_id',
			'cascade_save' => false,
			'cascade_delete' => false,
		),
	);

	private function chk_prop(){
		//プロパティーのチェック
		$this->list_price = ctype_digit($this->list_price) ? $this->list_price : null;
		$this->base_price =  ctype_digit($this->base_price) ? $this->base_price : null;
		$this->latest_pur_price =  ctype_digit($this->latest_pur_price) ? $this->latest_pur_price : null;
		$this->stock_type =  ctype_digit($this->stock_type) ? $this->stock_type : 1;

		//チェックボックスは配列で渡されるの巻
		if(is_array($this->is_open_price)){
			$this->is_open_price = $this->is_open_price[0];
		}else{
			$this->is_open_price = 0;
		}
		$this->is_open_price =  ctype_digit($this->is_open_price) ? $this->is_open_price : 0;
	}

	public function save($cascade = NULL, $use_transaction = false){
		$this->chk_prop();
		return parent::save($cascade,$use_transaction);
	}
}
