<?php

class Model_Image extends \Orm\Model
{
	protected static $_properties = array(
		'id',
		'item_id' => array('skip' => true),

		'image_seq' => array(
			'data_type' => 'int',
			'label' => '画像枝番',
			'validation' => array('valid_string'=>array(array('numeric')),'max_length'=>array(2)),
			'form' => array('type' => 'text'),
		),

		'image_url' => array(
			'data_type' => 'varchar',
			'label' => '画像URL',
			'validation' => array('max_length'=>array(200)),
			'form' => array('type' => 'text'),
		),

		'created_at' => array('skip' => true),
		'updated_at' => array('skip' => true),
	);

	protected static $_observers = array(
		'Orm\Observer_CreatedAt' => array(
			'events' => array('before_insert'),
			'mysql_timestamp' => false,
		),
		'Orm\Observer_UpdatedAt' => array(
			'events' => array('before_update'),
			'mysql_timestamp' => false,
		),
	);

	protected static $_table_name = 'image';
	protected static $_belongs_to = array(
			'item' => array(
					'key_from' => 'item_id',
					'model_to' => 'Model_Item',
					'key_to'   => 'id',
					'cascade_save' => false,
					'cascade_delete' => false,
			)
	);
}
