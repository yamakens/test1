<?php

class Model_Itemselect extends \Orm\Model
{
	protected static $_properties = array(
		'id',
		'item_id' => array('skip' => true),

		'horizontal_no' => array(
			'data_type' => 'varchar',
			'label' => '横軸枝番号',
			'validation' => array('max_length'=>array(32)),
			'form' => array('type' => 'text' ,'size' => 5),
		),
		'horizontal_name' => array(
			'data_type' => 'varchar',
			'label' => '横軸名称',
			'validation' => array('max_length'=>array(100)),
			'form' => array('type' => 'text'),
		),

		'vertical_no' => array(
			'data_type' => 'varchar',
			'label' => '横軸枝番号',
			'validation' => array('max_length'=>array(32)),
			'form' => array('type' => 'text', 'size' => 5),
		),

		'vertical_name'  => array(
			'data_type' => 'varchar',
			'label' => '横軸名称',
			'validation' => array('max_length'=>array(100)),
			'form' => array('type' => 'text'),
		),

		'stock_qty'   => array('skip' => true),
		'reserve_qty' => array('skip' => true),
		'created_at'  => array('skip' => true),
		'updated_at'  => array('skip' => true),
	);

	protected static $_observers = array(
		'Orm\Observer_CreatedAt' => array(
			'events' => array('before_insert'),
			'mysql_timestamp' => false,
		),
		'Orm\Observer_UpdatedAt' => array(
			'events' => array('before_update'),
			'mysql_timestamp' => false,
		),
	);

	protected static $_table_name = 'itemselect';
	protected static $_belongs_to = array(
		'item' => array(
			'key_from' => 'item_id',
			'model_to' => 'Model_Item',
			'key_to'   => 'id',
			'cascade_save' => false,
			'cascade_delete' => false,
		)
	);
}
