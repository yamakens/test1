<?php
class MyUtil{

	const FIELD_TEMPLATE = "{field}\n";
	const MULTI_FIELD_TEMPLATE = "{fields}{field} {label}\n{fields}\n";

	static function add_model($fieldset,$model,$prefix = ''){

		$_model = $model::forge();

		//Modelのpropertiesを取り込む
		foreach($_model->properties() as $key => $p){

			//skipとidは取り込まない
			if(isset($p['skip'])){
				continue;
			}
			if($key === 'id'){
				continue;
			}

			//フィールドが重複しないようにプレフィクスを付与して追加する
			$fieldset->add($key.$prefix, isset($p['label'])?$p['label']:'',isset($p['form'])?$p['form']:array());

			//validationがある場合はadd_rule
			if(isset($p['validation'])){
				foreach($p['validation'] as $v){
					//
					if(isset($v[0])&&isset($v[1])){
						$fieldset->field($key.$prefix)->add_rule($v[0],$v[1]);
					}
				}
			}

			//templateがある場合はset_template
			if(isset($p['template'])){
				$fieldset->field($key.$prefix)->set_template($p['template']);

			}else{

				switch(true){
					case $p['form']['type'] === 'radio':
						$fieldset->field($key.$prefix)->set_template(self::MULTI_FIELD_TEMPLATE);
						break;

					default:
						$fieldset->field($key.$prefix)->set_template(self::FIELD_TEMPLATE);
				}
			}
		}
		return $fieldset;
	}

	static function set_fields($fieldset, &$model, $prefix = ''){

		foreach ($model->properties() as $key => $p){
			if(isset($fieldset->field($key.$prefix)->value)){
				$model->$key = $fieldset->field($key.$prefix)->value;
			}else{
				$model->$key = '';
			}
		}
	}
}
