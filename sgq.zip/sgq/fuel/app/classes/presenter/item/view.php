<?php
use Fuel\Core\Presenter;
class Presenter_Item_View extends Presenter {
	public function view() {

		$stock_type_string = array(1=>'設定なし', 2=>'通常在庫', 3=>'項目選択肢別');

		//$this->data['item']->stock_type_string = $stock_type_string[$this->data['item']->stock_type];
		$this->item->stock_type_string = $stock_type_string[$this->item->stock_type];
		//$this->item = $this->data['item'];
	}
}