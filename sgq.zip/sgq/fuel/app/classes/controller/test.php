<?php
class Controller_test extends Controller
{
	public function action_index()
	{
		$fieldset = Myfieldset::forge('sample');
		$fieldset->addTextForNumeric('age', '年齢');
		$fieldset->addRadioWithBr('gender', '性別', array(1 => '男', 2 => '女'));
		$fieldset->addRadioInline('season', '一番好きな季節', array(1 => '春', 2 => '夏', 3 => '秋', 4 => '冬'));
		$view = View::forge('test/index');
		$view->set_safe(array('form' => $fieldset->getFormElements('post_url')));

		return Response::forge($view);
	}
}
