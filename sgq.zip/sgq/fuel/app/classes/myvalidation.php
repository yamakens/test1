<?php
class MyValidation
{
	public static function _validation_intnull(&$val){
		//数字じゃない場合はnullに変換する
		if(!ctype_digit($val)){
			$val = null;
		}
		//全て成功で返す
		return true;
	}
}